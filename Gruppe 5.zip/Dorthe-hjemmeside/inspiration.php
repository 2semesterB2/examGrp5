<!DOCTYPE html>
<html lang="da">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Mangler du motivation og inspiration i din hverdag, så kan du følge mine træningsøvelser og forslag til at forbedre din kost. Følg mig på Facebook, Instagram og YouTube.">
    <meta name="keywords" content="Træning, Sunde opskrifter, Motivation, Fysioterapi, Kostvejledning, Kost, Personlig Træning, Skadeforebyggelse Bootcamp, Inspiration, Mål, Fællesskab, Hjælp, Graviditet, Skader, Arbejdsskader, Overvægt, Vægttab, Sundhed, Fedttab, Kostplan, Træningsprogram, Livsstil, Dorthe Dalstrup, Skanderborg, Resultater, Før og efter, Stram-op, Rådgivning, Træningsøvelser, Personlig udvikling">

    <title>Inspiration | Dorthe Dalstrup - Personlig træner</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="css/stylesheet.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

<!-- Inkludering af PHP navigationsbar -->
<?php include 'php/navigation.php';?>

<div class="container-fluid">
  <div class="row margin-ryk padding-space margin-space">
    <div class="col-md-8 col-md-offset-2 col-sm-8 col-smoffset-2 col-xs-10 col-xs-offset-1">
      <h1 class="margin-space margin-ryk">Her kan du få inspiration til opskrifter og hverdagsøvelser</h1>
    </div>

    <!-- inspirationsbillede 1 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede1.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>

    <!-- inspirationsbillede 2 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede2.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>

    <!-- inspirationsbillede 3 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede3.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>


    <!-- inspirationsbillede 4 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede4.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>

    <!-- inspirationsbillede 5 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede5.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>

    <!-- inspirationsbillede 6 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede6.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>

    <!-- inspirationsbillede 7 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede7.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>


    <!-- inspirationsbillede 8 -->
    <div class="col-md-offset-2 col-md-3 col-sm-offset-1 col-sm-5 col-xs-offset-0 col-xs-12">
      <img src="images/inspirationsbilleder/inspiration-billede8.jpg" alt="facebook opslag som inspiration" width="100%" height="100%">
    </div>
  </div>
</div> <!-- Container END -->

<?php include 'php/footer.php' ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="js/navbar.js" charset="utf-8"></script>

  </body>
</html>
