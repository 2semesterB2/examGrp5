//Eksempel er hentet fra hjemmesiden: https://stackoverflow.com/questions/12738558/how-to-make-a-div-move-up-and-down-like-a-floating-baloon

var baloon = $('.baloon');
function runIt() {
    baloon.animate({top:'+=20'}, 1000);
    baloon.animate({top:'-=20'}, 1000, runIt);
}

runIt();
