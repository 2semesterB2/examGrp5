<!DOCTYPE html>
<html lang="da">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Personlig træning i Skanderborg.
    Jeg har et ønske om at hjælpe dig til at få en sundere livsstil og opnå det vægttab,
    som du ønsker. Jeg er uddannet fysioterapeut, kostvejleder og personlig træner.">
    <meta name="keywords" content="Træning, Sunde opskrifter, Motivation, Fysioterapi, Kostvejledning, Kost, Personlig Træning, Skadeforebyggelse Bootcamp, Inspiration, Mål, Fællesskab, Hjælp, Graviditet, Skader, Arbejdsskader, Overvægt, Vægttab, Sundhed, Fedttab, Kostplan, Træningsprogram, Livsstil, Dorthe Dalstrup, Skanderborg, Resultater, Før og efter, Stram-op, Rådgivning, Træningsøvelser, Personlig udvikling">
    <title>Forside | Dorthe Dalstrup - Personlig træner</title>

    <!-- Bootstrap vi anvender gennem hele hjemmesiden bliver hentet fra disse links -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="css/stylesheet.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

<!-- Henter navigationsbaren til siden -->
<?php include 'php/navigation.php';?>
<div class="container-fluid">
<!-- Bruges til jQuery vedr. smooth-scroll.js -->
<div id="page-wrap">
  <section class="window">
    <!-- Viser det store frontsidebillede -->
    <header>
      <div class="row">
        <div class=" hidden-xs col-md-12 col-xs-12 img-size">
          <img class="img-float text-right logo-design" src="images/logo-hvid2.png" alt="Dorthe Dalstrup logo" width="50%" height="auto">
          <img src="images/forside-billede.jpg" alt="Billede af Dorthe Dalstrup der træner" width="100%" height="100%">
          <div id="one">
            <a class="color-white" href="#one"><span class="baloon midt-placering glyphicon glyphicon-chevron-down glyph-arrow-design hidden-xs"></span></a>
          </div>
        </div>
      </div> <!-- Row END-->
    </header>
  </section>

<!-- Første sektion efter billedet -->
<div class="row margin-space padding-space">
  <div class="col-md-offset-2 col-md-4 col-xs-12">
    <h1>Om mig</h1>
    <h3>Jeg vil gerne hjælpe mennesker til at leve et sundt og smertefrit liv</h3>
      <p class="text-justify">Min passion er at gøre hverdagen nemmere for dig gennem sundhed og træning. Jeg vil gerne hjælpe dig med at ændre små ting i din dagligdag. Små ting som kan have stor betydning for din hverdag og livskvalitet. Det er vigtigt for mig, at det ikke bliver en pligt, men en livsstil, da jeg ikke går ind for forbud i forhold til kost. Jeg informerer, rådgiver og kommer med løsninger, som passer til lige netop dig, da jeg går op i at det skal være personligt og ingen mennesker er ens. <br><br> Programmet bliver skræddersyet til dig og dine behov ligegyldigt om du vil tabe dig, blive stærkere eller har skader. Jeg ønsker, at hjælpe dig til at blive motiveret til at fortsætte med at leve sundt og træne. Jeg vil gerne være et skridt på vejen, så du fremover kan være den bedste udgave af dig selv. Jeg kan med nedenstående forløb hjælpe dig med at opnå netop dine drømme og dine mål!
      </p>
<br>
      <a href="om-mig.php"><button type="button" class="btn btn-info btn-koeb-design">Læs mere »</button></a>
  </div>
  <div class="col-md-4 col-xs-12">
    <iframe class="video-margin" width="100%" height="400px" src="https://www.youtube.com/embed/-MzKo5Kd1PM" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
    <p class="font-italic text-center">"Jeg vil gerne være et skridt på vejen, så du fremover kan være den bedste udgave af dig selv."</p>
  </div>
</div>
</div>

<!-- Anden sektion efter "om mig" -->
<div id="two">
  <div class="padding-space row blue-bg">
    <div class="col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
      <h1 class="color-white">Anmeldelser</h1>
    </div>
    <div class="col-md-12 col-xs-12">
<!-- Personanmeldelse 1 -->
      <div class="col-md-offset-2 col-md-2 col-sm-6 col-xs-12">
        <img class="img-margin" src="images/anmeldelser/amalie.jpg" alt="Billede af Amalie" width="100%" height="100%">
          <div class="glyphicon-placering">
            <h3 class="color-white">Amalie</h3>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
          </div>
        <div class="quote text-justify">
          <p>"Super træner. Har øje for god udførelse af mange forskellige øvelser. Hun Følger op på skavankerne"</p>
        </div>
      </div>

<!-- Personanmeldelse 2 -->
      <div class="col-md-offset-1 col-md-2 col-sm-6 col-xs-12">
        <img class="img-margin" src="images/anmeldelser/vibeke.jpg" alt="Billede af Vibeke" width="100%" height="100%">
          <div class="glyphicon-placering">
            <h3 class="color-white">Vibeke</h3>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star-empty glyphicon-design"></span>
          </div>
        <div class="quote text-justify">
          <p>"Dorthe er motiverende med go' energi. Tydelig & tålmodig ift. hvor vi er"</p>
        </div>
      </div>

<!-- Personanmeldelse 3 -->
      <div class="col-md-offset-1 col-md-2 col-sm-6 col-xs-12">
        <img class="img-margin" src="images/anmeldelser/elizabeth.jpg" alt="Billede af Elizabeth" width="100%" height="100%">
          <div class="glyphicon-placering">
            <h3 class="color-white">Elizabeth</h3>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
            <span class="glyphicon glyphicon-star glyphicon-design"></span>
          </div>
        <div class="quote text-justify">
          <p>"God til at tage individuel hensyn samt at motiver. Have god føling med at presse os. Tak for en god træning"</p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- tredje sektion efter anmeldelserne -->
<div id="three">
  <div class="row margin-space">
    <div class="col-md-offset-2 col-md-3 col-sm-12 col-xs-12">
      <h1>Kontakt mig i dag</h1>
      <!-- kontaktformularen -->
        <form class="" action="php/mail.php" method="post">
          <div class="form-group">
            <label>Fulde navn</label>
            <input type="text" class="form-control" id="navn" name="a_name" required placeholder="Dorthe Dalstrup">
            <label>Køn</label> <br>
            <input type="radio" name="a_options" value="Mand" id="option1" checked> Mand
            <input type="radio" name="a_options" value="Kvinde" id="option2" > Kvinde <br>
            <label>E-mail</label>
            <input type="email" class="form-control" id="email" name="a_email" required placeholder="din@email.her">
            <label>Besked</label>
            <textarea class="form-control" id="comment" name="a_comment" rows="5" required placeholder="Skriv en kort beskrivelse om dig selv"></textarea> <br>
			         <input type="submit" class="btn btn-info btn-koeb-design" text="Send" value="Indsend »" button>
          </div>
        </div>
        <!-- Kodeeksemplet er hentet fra hjemmesiden https://www.w3schools.com/css/css_align.asp -->
    <div class="col-md-offset-1 col-md-4 col-sm-12 col-xs-12">
      <h2>Vejen til Globe Fitness</h2>
      <h3>Krøyer Kielbergs Vej 3, Skanderborg 8660</h3>
      <!-- Responsivt Google API -->
        <div class="embed-responsive embed-responsive-16by9">
          <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2228.615497030902!2d9.923328116172403!3d56.042646080631904!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x464c6ef628197025%3A0x630352dabf689c5a!2sKr%C3%B8yer+Kielbergs+Vej+3%2C+8660+Skanderborg!5e0!3m2!1sen!2sdk!4v1512568518078" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
  </div>
</div>
</div>
</div> <!-- Container END -->

<?php include 'php/footer.php' ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!-- Tilføjelse af Script til siden -->
<script src="js/smooth-scroll.js" charset="utf-8"></script>
<script src="js/navbar.js" charset="utf-8"></script>
<script src="js/float.js" charset="utf-8"></script>

  </body>
</html>
