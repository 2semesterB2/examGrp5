<!-- Design af HTML footer er placeret her -->
<footer>
  <div class="container-fluid">
    <div class="row blue-bg text-center">
      <div class="col-md-offset-5 col-md-2 col-sm-2 col-sm-offset-0 col-xs-8 col-xs-offset-2">
        <div class="col-md-4 sociale-medier-design">
          <a href="https://www.instagram.com/personligtraenerdorthedalstrup/"><img src="images/footer/instagram.png" alt="Instagram logo" title="Følg mig på Instagram!" width="100%" height="100%"></a>

        </div>
        <div class="col-md-4 sociale-medier-design">
  <a href="https://www.facebook.com/personligtraenerdorthedalstrup/"><img src="images/footer/facebook.png" alt="Facebook logo" title="Følg mig på Facebook!" width="100%" height="100%"></a>
        </div>
        <div class="col-md-4 sociale-medier-design">
          <a href="#!"><img src="images/footer/youtube.png" alt="Youtube logo" title="Følg mig på Youtube!" width="100%" height="100%"></a>
        </div>
      </div>
    </div>

  <div class="row blue-bg">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <p class="text-center text-md-center text-sm-center text-xs-center footer-p">Copyright Dorthe Dalstrup 2017 ©</p>
    </div>
  </div>
</div>
</footer>
