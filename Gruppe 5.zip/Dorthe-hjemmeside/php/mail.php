<head>
    <meta charset="utf-8">
</head>

<!-- Kode fundet på hjemmesiden https://1stwebdesigner.com/php-contact-form-html/ -->

<!-- Tilføjer tekst -->
<?php
echo "Sender e-mail!";
// Angiver variabler ud fra kontaktformularen
$name = $_POST["a_name"];
$email = $_POST["a_email"];
$options = $_POST["a_options"];
$message = $_POST["a_comment"];

// Kalder på samtlige variabler
echo($name);
echo($email);
echo($options);
echo($message);

// Tilføjelse af hendes e-mail
$recipient = "Nikolaj@kiil.nu";
$formcontent="Indtastet navn: $name \nKøn: $options \nBesked: $message";
//$email = "emailaddress@here.com";
// Emne i en e-mail
$subject = "Ny kundebesked!";
// Angiver hvem e-mailen er fra
$mailheader = "From: $email \r\n";

// indbygget mailfunktion i PHP
mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
echo "\nTak for din mail!";
?>

<?php
?>
