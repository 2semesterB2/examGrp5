<!-- Eksemplet er hentet fra hjemmesiden https://teamtreehouse.com/community/bootstrap-responsive-burger-menu-not-functioning-on-mobile-device -->

<!-- Hele navigationsbaren vi anvender på hjemmesiden, bliver hentet herfra vha. en include i PHP -->
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container-fluid">
      <!-- Logo af dorthe og hvor meget det fylder på siden -->
      <div class="col-md-2 col-xs-offset-0 col-xs-7">
        <div class="navbar-header">
          <a class="" href="index.php"><img class="logo-margin" src="images/logo.gif" alt="Dorthe Dalstrup logo" width="100%" height="100%"></a>
        </div>
      </div>
      <!-- Placering og design af burgermenu hentet fra Bootstrap og tilpasset til vores behov -->
      <div class="col-sm-3 col-sm-offset-2 col-xs-3 col-xs-offset-2">
        <button type="button" class="navbar-toggle collapsed text-center" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      </div>
      <!-- Navigationsbar links der fremkommer i navigationsbaren -->
      <div class="col-md-8 col-sm-10 col-sm-offset-1 col-xs-offset-1 col-xs-10">
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a class="nav-link" href="index.php">Forside</a></li>
            <li><a class="nav-link" href="om-mig.php">Om mig</a></li>
            <li><a class="nav-link" href="inspiration.php">Inspiration</a></li>
            <li><a class="nav-link" href="services.php">Services</a></li>
            <li><a class="nav-link" href="kontakt.php">Kontakt</a></li>
            <li><a class="nav-link" href="login.php">Log ind <div class="glyphicon glyphicon-user glyphicon-user-design"></div></a></li>
          </ul>
        </div>
      </div>
    </div>
  </nav>

<!-- ////////////////////////////// -->
<!-- Gammel navigations menu, uden burgermenu. DENNE KODE BRUGES IKKE MERE!-->
<!-- ////////////////////////////// -->

<!-- <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 col-xs-offset-1 col-xs-9">
        <a href="index.php"><img class="logo-margin" src="images/logo.png" alt="Dorthe Dalstrup logo" width="100%" height="100%"></a>
      </div>
      <div class="col-md-8 col-xs-12 text-right nav-margin">
        <a class="nav-link" href="index.php">Forside</a>
        <a class="nav-link" href="om-mig.php">Om mig</a>
        <a class="nav-link" href="inspiration.php">Inspiration</a>
        <a class="nav-link" href="services.php">Services</a>
        <a class="nav-link" href="kontakt.php">Kontakt</a>
        <a class="nav-link" href="login.php">Log ind <div class="glyphicon glyphicon-user"></div></a>
      </div>
    </div>
  </div>
</nav> -->
