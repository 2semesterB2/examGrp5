<!DOCTYPE html>
<html lang="da">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Jeg hedder Dorthe Dalstrup. Jeg er uddannet personlig træner, fysioterapeut og kostvejleder. Jeg har fokus på sundhed, øget velvære og genvunden motivation for en sund livsstil. Jeg har stor erfaring med skadesbehandling.">
    <meta name="keywords" content="Træning, Sunde opskrifter, Motivation, Fysioterapi, Kostvejledning, Kost, Personlig Træning, Skadeforebyggelse Bootcamp, Inspiration, Mål, Fællesskab, Hjælp, Graviditet, Skader, Arbejdsskader, Overvægt, Vægttab, Sundhed, Fedttab, Kostplan, Træningsprogram, Livsstil, Dorthe Dalstrup, Skanderborg, Resultater, Før og efter, Stram-op, Rådgivning, Træningsøvelser, Personlig udvikling">

    <title>Om mig | Dorthe Dalstrup - Personlig træner</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="css/stylesheet.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>

<?php include 'php/navigation.php';?>

<div class="container-fluid">
  <div class="row margin-space margin-ryk">
    <div class="margin-space col-md-offset-2 col-md-4 col-sm-12 col-xs-12">
      <h1>Alt om mig</h1>
      <h3>Smil til verdenen og den smiler til dig</h3>
      <p class="text-justify">Mit navn er Dorthe Dalstrup. Jeg arbejder som personlig træner i Skanderborg. Jeg arbejder med alt indenfor vægttab, skadesbehandling, øget velvære, forbedret sundhed, øget styrke og genfunden motivation for en sund livsstil. <br><br>Jeg mener, at vi alle er unikke og derfor kan der heller ikke laves en løsning til, hvordan alle mennesker skal træne og spise. Jeg tager derfor udgangspunkt i dig og dine behov. Ud fra dette skræddersyr jeg træningsprogram og hjælper med ændringer i din daglige kost. Så du fremover kan være den bedste udgave af dig selv. <br> <br>
      Ved siden af mit job, som personlig træner, er jeg uddannet fysioterapeut og studerende på kandidatuddannelsen i sundhed og idræt. Jeg vil gerne hjælpe mennesker til at leve et sundt og smertefrit liv, selvom de måske har haft eller har skader.</p>

      <br><br>

      <div class="blue-bg bloed-kant col-md-12 col-sm-12 col-xs-12">
        <h1 class="color-white"> Uddannelse</h1>
        <!-- Styling af uddannelsesboks -->
        <ul class="list-height padding-bottom color-white">
          <li>Kandidatstuderende i Idræt og Sundhed ved SDU (2016-2018)</li>
          <li>Kostvejleder</li>
          <li>Styrketræning for særlige målgrupper; børn, gravide, ældre</li>
          <li>Idrætsfysioterapi og knæ, fod/ankel, skulder</li>
          <li>Professionsbachelor i Fysioterapi 2015</li>
        </ul>
      </div>
      </div>
      <div class=" col-md-4 col-sm-12 col-xs-12">
        <img src="images/om-mig/dorthe-selvportraet.png" alt="Selvportræt af Dorthe Dalstrup" width="100%" height="100%">
      </div>
  </div>
</div> <!-- Container END -->

<?php include 'php/footer.php' ?>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script src="js/navbar.js" charset="utf-8"></script>

  </body>
</html>
